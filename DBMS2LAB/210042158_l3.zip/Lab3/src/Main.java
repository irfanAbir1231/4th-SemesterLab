import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            // Step 1: Load the driver class
            Class.forName("oracle.jdbc.driver.OracleDriver");

            // Step 2: Create the connection object
            Connection con = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:xe", "irfan4", "123");

            // Step 3: Create the statement object
            Statement stmt = con.createStatement();

            // Task 1: Decrease the budget of the departments having a budget of more than 99999 by 10%
            System.out.println(" Decreasing budget of departments...");
            String decreaseBudgetSql = "UPDATE department SET budget = budget * 0.9 WHERE budget > 99999";
            int affectedRows = stmt.executeUpdate(decreaseBudgetSql);
            System.out.println("Number of departments affected: " + affectedRows);

// Show the number of departments that did not get affected
            String unaffectedDepartmentsSql = "SELECT COUNT(*) AS unaffectedCount FROM department WHERE budget <= 99999";
            ResultSet unaffectedRs = stmt.executeQuery(unaffectedDepartmentsSql);
            if (unaffectedRs.next()) {
                int unaffectedCount = unaffectedRs.getInt("unaffectedCount");
                System.out.println("Number of departments not affected: " + unaffectedCount);
            }
            unaffectedRs.close();


            // Task 2: Take input from the user and find instructors taking classes during that time
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter day of the week (e.g., M): ");
            String day = scanner.next().toUpperCase();
            System.out.print("Enter starting hour (0-23): ");
            int startHour = scanner.nextInt();
            System.out.print("Enter ending hour (0-23): ");
            int endHour = scanner.nextInt();

            String instructorsTakingClassesSql = "SELECT DISTINCT name FROM instructor i " +
                    "JOIN teaches t ON i.ID = t.ID " +
                    "JOIN section s ON t.course_id = s.course_id AND t.sec_id = s.sec_id " +
                    "JOIN time_slot ts ON s.time_slot_id = ts.time_slot_id " +
                    "WHERE ts.day = '" + day + "' AND ts.start_hr <= " + endHour + " AND ts.end_hr >= " + startHour;

            ResultSet instructorsTakingClassesRs = stmt.executeQuery(instructorsTakingClassesSql);
            System.out.println(" Instructors taking classes during that time:");
            while (instructorsTakingClassesRs.next()) {
                System.out.println(instructorsTakingClassesRs.getString("name"));
            }
            instructorsTakingClassesRs.close();

            // Task 3: Find top N students based on the number of courses they are enrolled in

            // Task 3: Find top N students based on the number of courses they are enrolled in
            System.out.print(" Enter N to find top N students: ");
            int topN = scanner.nextInt();

            String topNStudentsSql = "SELECT * FROM (SELECT s.ID, s.name, s.dept_name, COUNT(t.course_id) AS num_courses, " +
                    "ROW_NUMBER() OVER (ORDER BY COUNT(t.course_id) DESC) AS rnum " +
                    "FROM student s LEFT JOIN takes t ON s.ID = t.ID " +
                    "GROUP BY s.ID, s.name, s.dept_name " +
                    "ORDER BY num_courses DESC) WHERE rnum <= ?";

// Use a prepared statement to set the parameter
            PreparedStatement topNStudentsStmt = con.prepareStatement(topNStudentsSql);
            topNStudentsStmt.setInt(1, topN);

            ResultSet topNStudentsRs = topNStudentsStmt.executeQuery();

            System.out.println(" Top " + topN + " students based on the number of courses:");
            while (topNStudentsRs.next()) {
                String studentID = topNStudentsRs.getString("ID");
                String studentName = topNStudentsRs.getString("name");
                String studentDept = topNStudentsRs.getString("dept_name");
                int numCourses = topNStudentsRs.getInt("num_courses");

                System.out.println("ID: " + studentID + ", Name: " + studentName + ", Department: " +
                        studentDept + ", Number of Courses: " + numCourses);
            }
            topNStudentsRs.close();
            topNStudentsStmt.close();



            // Task 4: Insert a new student named 'Jane Doe'
            // The student should be enrolled in the department having the lowest number of students.
            // The ID of the student will be (X + 1), where X is the highest ID value among the existing students.
            String findLowestDeptSql = "SELECT dept_name FROM department ORDER BY (SELECT COUNT(*) FROM student WHERE dept_name = department.dept_name) ASC FETCH FIRST ROW ONLY";
            ResultSet lowestDeptRs = stmt.executeQuery(findLowestDeptSql);
            String lowestDept = "";
            if (lowestDeptRs.next()) {
                lowestDept = lowestDeptRs.getString("dept_name");
            }
            lowestDeptRs.close();

            String findHighestIdSql = "SELECT MAX(TO_NUMBER(ID)) AS max_id FROM student";
            ResultSet highestIdRs = stmt.executeQuery(findHighestIdSql);
            int newId = 1;
            if (highestIdRs.next()) {
                newId = highestIdRs.getInt("max_id") + 1;
            }
            highestIdRs.close();

            String insertNewStudentSql = "INSERT INTO student VALUES ('" + String.format("%05d", newId) + "', 'Jane Doe', '" + lowestDept + "', 0)";
            stmt.executeUpdate(insertNewStudentSql);
            System.out.println(" New student 'Jane Doe' inserted.");

            // Task 5: Find students without advisors and assign them an advisor from their department
            // In case of multiple instructors, select the advisor based on the least number of students advised
            String findStudentsWithoutAdvisorSql = "SELECT s.ID, s.name, s.dept_name FROM student s " +
                    "LEFT JOIN advisor a ON s.ID = a.s_ID WHERE a.s_ID IS NULL";

            ResultSet studentsWithoutAdvisorRs = stmt.executeQuery(findStudentsWithoutAdvisorSql);
            System.out.println(" Students without advisors and their assigned advisors:");
            while (studentsWithoutAdvisorRs.next()) {
                String studentId = studentsWithoutAdvisorRs.getString("ID");
                String studentName = studentsWithoutAdvisorRs.getString("name");
                String studentDept = studentsWithoutAdvisorRs.getString("dept_name");

                String assignAdvisorSql = "SELECT ID FROM instructor i " +
                        "WHERE i.dept_name = '" + studentDept + "' " +
                        "ORDER BY (SELECT COUNT(*) FROM advisor WHERE i.ID = i_ID) ASC FETCH FIRST ROW ONLY";

                ResultSet advisorRs = stmt.executeQuery(assignAdvisorSql);
                String advisorId = "";
                if (advisorRs.next()) {
                    advisorId = advisorRs.getString("ID");
                }
                advisorRs.close();

                String assignAdvisorUpdateSql = "INSERT INTO advisor VALUES ('" + studentId + "', '" + advisorId + "')";
                stmt.executeUpdate(assignAdvisorUpdateSql);
                System.out.println("Student: " + studentName + ", Advisor ID: " + advisorId);
            }
            studentsWithoutAdvisorRs.close();

            // Step 6: Close the connection object
            con.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
